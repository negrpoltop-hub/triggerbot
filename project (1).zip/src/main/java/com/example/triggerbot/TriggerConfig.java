package com.example.triggerbot;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class TriggerConfig {
    // ---- Не сохраняются: после запуска игры всё выключено ----
    public static boolean enabled = false;      // TriggerBot
    public static boolean aimEnabled = false;   // Доводка

    // ---- Общие цели ----
    public static boolean targetPlayers = true;
    public static boolean targetHostile = true;
    public static boolean targetPassive = false;

    // ---- TriggerBot ----
    public static boolean weaponOnly = false;
    /** Минимальная «сила удара» (кулдаун оружия) в процентах, 50..100. */
    public static int cooldownPercent = 100;
    /** Задержка перед ударом в миллисекундах, 0..300. */
    public static int delayMs = 0;
    /** Авто-свап на копьё из хотбара (только копья БЕЗ Рывка/Lunge — голод не тратится). */
    public static boolean autoSpear = false;
    /** После боя вернуть прежний слот. */
    public static boolean spearSwapBack = true;

    // ---- Доводка ----
    /** Дальность в блоках, 2..8. */
    public static int aimRange = 4;
    /** Полный угол обзора (конус) в градусах, 10..180. */
    public static int aimFov = 60;
    /** Скорость наведения: доля оставшегося угла за тик, 5..100 %. */
    public static int aimSpeed = 25;
    /** Работать только пока зажата кнопка атаки. */
    public static boolean aimOnlyWhenAttacking = true;
    /** Целиться в голову (иначе в центр тела). */
    public static boolean aimHead = false;

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("triggerbot.properties");
    }

    private TriggerConfig() {}

    public static void load() {
        Path file = file();
        if (!Files.exists(file)) return;
        Properties p = new Properties();
        try (Reader in = Files.newBufferedReader(file)) {
            p.load(in);
            targetPlayers = Boolean.parseBoolean(p.getProperty("targetPlayers", "true"));
            targetHostile = Boolean.parseBoolean(p.getProperty("targetHostile", "true"));
            targetPassive = Boolean.parseBoolean(p.getProperty("targetPassive", "false"));
            weaponOnly = Boolean.parseBoolean(p.getProperty("weaponOnly", "false"));
            cooldownPercent = clamp(parseInt(p.getProperty("cooldownPercent"), 100), 50, 100);
            delayMs = clamp(parseInt(p.getProperty("delayMs"), 0), 0, 300);
            autoSpear = Boolean.parseBoolean(p.getProperty("autoSpear", "false"));
            spearSwapBack = Boolean.parseBoolean(p.getProperty("spearSwapBack", "true"));
            aimRange = clamp(parseInt(p.getProperty("aimRange"), 4), 2, 8);
            aimFov = clamp(parseInt(p.getProperty("aimFov"), 60), 10, 180);
            aimSpeed = clamp(parseInt(p.getProperty("aimSpeed"), 25), 5, 100);
            aimOnlyWhenAttacking = Boolean.parseBoolean(p.getProperty("aimOnlyWhenAttacking", "true"));
            aimHead = Boolean.parseBoolean(p.getProperty("aimHead", "false"));
        } catch (IOException | RuntimeException e) {
            TriggerBotClient.LOGGER.warn("Could not read config", e);
        }
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("targetPlayers", Boolean.toString(targetPlayers));
        p.setProperty("targetHostile", Boolean.toString(targetHostile));
        p.setProperty("targetPassive", Boolean.toString(targetPassive));
        p.setProperty("weaponOnly", Boolean.toString(weaponOnly));
        p.setProperty("cooldownPercent", Integer.toString(cooldownPercent));
        p.setProperty("delayMs", Integer.toString(delayMs));
        p.setProperty("autoSpear", Boolean.toString(autoSpear));
        p.setProperty("spearSwapBack", Boolean.toString(spearSwapBack));
        p.setProperty("aimRange", Integer.toString(aimRange));
        p.setProperty("aimFov", Integer.toString(aimFov));
        p.setProperty("aimSpeed", Integer.toString(aimSpeed));
        p.setProperty("aimOnlyWhenAttacking", Boolean.toString(aimOnlyWhenAttacking));
        p.setProperty("aimHead", Boolean.toString(aimHead));
        try (Writer out = Files.newBufferedWriter(file())) {
            p.store(out, "TriggerBot");
        } catch (IOException e) {
            TriggerBotClient.LOGGER.warn("Could not save config", e);
        }
    }

    private static int parseInt(String s, int fallback) {
        try {
            return s == null ? fallback : Integer.parseInt(s.trim());
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    private static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }
}
