package com.example.triggerbot;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

/** Плавная доводка прицела к ближайшей к центру экрана цели. */
public final class AimAssist {
    private AimAssist() {}

    public static void tick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (!TriggerConfig.aimEnabled
                || player == null
                || client.world == null
                || client.currentScreen != null
                || player.isSpectator()) {
            return;
        }
        if (TriggerConfig.aimOnlyWhenAttacking && !client.options.attackKey.isPressed()) {
            return;
        }

        double eyeX = player.getX();
        double eyeY = player.getEyeY();
        double eyeZ = player.getZ();
        double range = TriggerConfig.aimRange;
        double halfFov = TriggerConfig.aimFov / 2.0;

        double bestAngle = halfFov;
        double bestDYaw = 0;
        double bestDPitch = 0;
        boolean found = false;

        for (Entity entity : client.world.getEntities()) {
            if (entity == player || entity.isSpectator() || !Targets.isValid(entity)) continue;

            double tx = entity.getX();
            double ty = TriggerConfig.aimHead ? entity.getEyeY() : entity.getY() + entity.getHeight() * 0.5;
            double tz = entity.getZ();

            double dx = tx - eyeX;
            double dy = ty - eyeY;
            double dz = tz - eyeZ;
            double distSq = dx * dx + dy * dy + dz * dz;
            if (distSq > range * range) continue;
            if (!player.canSee(entity)) continue; // только если цель видна (нет стен между вами)

            double horizontal = Math.sqrt(dx * dx + dz * dz);
            double targetYaw = Math.toDegrees(Math.atan2(dz, dx)) - 90.0;
            double targetPitch = -Math.toDegrees(Math.atan2(dy, horizontal));

            double dYaw = MathHelper.wrapDegrees(targetYaw - player.getYaw());
            double dPitch = targetPitch - player.getPitch();
            double angle = Math.sqrt(dYaw * dYaw + dPitch * dPitch);

            if (angle < bestAngle) {
                bestAngle = angle;
                bestDYaw = dYaw;
                bestDPitch = dPitch;
                found = true;
            }
        }

        if (!found) return;

        double speed = TriggerConfig.aimSpeed / 100.0;
        player.setYaw(player.getYaw() + (float) (bestDYaw * speed));
        player.setPitch(MathHelper.clamp(player.getPitch() + (float) (bestDPitch * speed), -90.0f, 90.0f));
    }
}
