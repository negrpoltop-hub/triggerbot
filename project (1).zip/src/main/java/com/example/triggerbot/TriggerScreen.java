package com.example.triggerbot;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.Supplier;

public class TriggerScreen extends Screen {
    private static final int COL_W = 150;
    private static final int GAP = 10;
    private static final int ROW_H = 24;

    /** 0 — TriggerBot, 1 — доводка. */
    private final int page;
    private int top;

    public TriggerScreen() {
        this(0);
    }

    private TriggerScreen(int page) {
        super(Text.translatable("triggerbot.title"));
        this.page = page;
    }

    public static Text onOff(boolean value) {
        return Text.translatable(value ? "options.on" : "options.off")
                .formatted(value ? Formatting.GREEN : Formatting.RED);
    }

    private static Text label(String key, boolean value) {
        return Text.translatable("triggerbot." + key)
                .append(Text.literal(": "))
                .append(onOff(value));
    }

    @Override
    protected void init() {
        int left = this.width / 2 - COL_W - GAP / 2;
        int right = this.width / 2 + GAP / 2;
        top = Math.max(60, this.height / 2 - 70);

        // Вкладки
        addTab(left, "tab_trigger", 0);
        addTab(right, "tab_aim", 1);

        int rows;
        if (page == 0) {
            rows = 5;
            toggle(left, top, "enabled", () -> TriggerConfig.enabled, v -> TriggerConfig.enabled = v);
            targets(left, top + ROW_H);

            toggle(right, top, "weapon_only", () -> TriggerConfig.weaponOnly, v -> TriggerConfig.weaponOnly = v);
            addDrawableChild(new IntSlider(right, top + ROW_H, COL_W, 20, "cooldown", 50, 100,
                    TriggerConfig.cooldownPercent, "%", v -> TriggerConfig.cooldownPercent = v));
            addDrawableChild(new IntSlider(right, top + ROW_H * 2, COL_W, 20, "delay", 0, 300,
                    TriggerConfig.delayMs, " ms", v -> TriggerConfig.delayMs = v));
            toggle(right, top + ROW_H * 3, "auto_spear", () -> TriggerConfig.autoSpear, v -> TriggerConfig.autoSpear = v);
            toggle(right, top + ROW_H * 4, "spear_back", () -> TriggerConfig.spearSwapBack, v -> TriggerConfig.spearSwapBack = v);
        } else {
            rows = 6;
            toggle(left, top, "aim_enabled", () -> TriggerConfig.aimEnabled, v -> TriggerConfig.aimEnabled = v);
            targets(left, top + ROW_H);

            toggle(right, top, "aim_attacking", () -> TriggerConfig.aimOnlyWhenAttacking, v -> TriggerConfig.aimOnlyWhenAttacking = v);
            toggle(right, top + ROW_H, "aim_head", () -> TriggerConfig.aimHead, v -> TriggerConfig.aimHead = v);
            addDrawableChild(new IntSlider(right, top + ROW_H * 2, COL_W, 20, "aim_range", 2, 8,
                    TriggerConfig.aimRange, "", v -> TriggerConfig.aimRange = v));
            addDrawableChild(new IntSlider(right, top + ROW_H * 3, COL_W, 20, "aim_fov", 10, 180,
                    TriggerConfig.aimFov, "\u00B0", v -> TriggerConfig.aimFov = v));
            addDrawableChild(new IntSlider(right, top + ROW_H * 4, COL_W, 20, "aim_speed", 5, 100,
                    TriggerConfig.aimSpeed, "%", v -> TriggerConfig.aimSpeed = v));
            toggle(right, top + ROW_H * 5, "aim_with_trigger", () -> TriggerConfig.aimWithTrigger, v -> TriggerConfig.aimWithTrigger = v);
        }

        addDrawableChild(ButtonWidget.builder(Text.translatable("triggerbot.done"), b -> close())
                .dimensions(left, top + ROW_H * rows + 4, COL_W * 2 + GAP, 20)
                .build());
    }

    private void addTab(int x, String key, int index) {
        ButtonWidget button = ButtonWidget.builder(Text.translatable("triggerbot." + key), b -> {
            TriggerConfig.save();
            this.client.setScreen(new TriggerScreen(index));
        }).dimensions(x, top - 28, COL_W, 20).build();
        button.active = index != page;
        addDrawableChild(button);
    }

    /** Общие для обоих режимов переключатели целей (3 строки). */
    private void targets(int x, int y) {
        toggle(x, y, "players", () -> TriggerConfig.targetPlayers, v -> TriggerConfig.targetPlayers = v);
        toggle(x, y + ROW_H, "hostile", () -> TriggerConfig.targetHostile, v -> TriggerConfig.targetHostile = v);
        toggle(x, y + ROW_H * 2, "passive", () -> TriggerConfig.targetPassive, v -> TriggerConfig.targetPassive = v);
    }

    private void toggle(int x, int y, String key, Supplier<Boolean> getter, Consumer<Boolean> setter) {
        addDrawableChild(ButtonWidget.builder(label(key, getter.get()), b -> {
            boolean v = !getter.get();
            setter.accept(v);
            b.setMessage(label(key, v));
        }).dimensions(x, y, COL_W, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, top - 44, 0xFFFFFFFF);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        TriggerConfig.save();
        super.close();
    }

    private static final class IntSlider extends SliderWidget {
        private final String key;
        private final int min;
        private final int max;
        private final String suffix;
        private final IntConsumer setter;

        IntSlider(int x, int y, int w, int h, String key, int min, int max, int current,
                  String suffix, IntConsumer setter) {
            super(x, y, w, h, Text.empty(), (double) (current - min) / (max - min));
            this.key = key;
            this.min = min;
            this.max = max;
            this.suffix = suffix;
            this.setter = setter;
            updateMessage();
        }

        private int currentValue() {
            return (int) Math.round(min + this.value * (max - min));
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.translatable("triggerbot." + key)
                    .append(Text.literal(": " + currentValue() + suffix)));
        }

        @Override
        protected void applyValue() {
            setter.accept(currentValue());
        }
    }
}
