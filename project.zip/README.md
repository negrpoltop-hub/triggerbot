# TriggerBot (Fabric, Minecraft 1.21.11)

Клиентский мод: бьёт сущность, на которую наведён прицел.

- **B** или **M** — открыть меню
- **R** — включить/выключить
- Все клавиши меняются в Настройки → Управление → TriggerBot

## Сборка
1. Нужна Java 21.
2. Откройте папку в IntelliJ IDEA (Gradle подтянется сам) и запустите задачу `build`,
   либо в терминале: `gradle wrapper --gradle-version 9.2.1` и `./gradlew build`.
3. Готовый мод: `build/libs/triggerbot-1.0.0.jar` → в папку `mods` (нужен Fabric Loader + Fabric API).
