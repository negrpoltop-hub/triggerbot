# TriggerBot + Aim assist (Fabric, Minecraft 1.21.11)

Клиентский мод.

- **B** или **M** — меню (две вкладки: TriggerBot и Доводка)
- **R** — вкл/выкл TriggerBot
- **G** — вкл/выкл доводку
- Клавиши меняются в Настройки → Управление → TriggerBot

Сборка: см. build.gradle (Java 21, Gradle 9.2.1) или GitHub Actions.
