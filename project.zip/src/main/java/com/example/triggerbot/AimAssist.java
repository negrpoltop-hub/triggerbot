package com.example.triggerbot;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;

import java.util.function.Predicate;

/** Плавная доводка прицела к ближайшей к центру экрана цели. */
public final class AimAssist {
    private static final Predicate<LivingEntity> VALID = Targets::isValid;

    private AimAssist() {}

    public static void tick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (!TriggerConfig.aimEnabled
                || player == null
                || client.world == null
                || client.currentScreen != null
                || player.isSpectator()
                || !player.isAlive()) {
            return;
        }
        if (TriggerConfig.aimOnlyWhenAttacking && !client.options.attackKey.isPressed()) {
            return;
        }

        double eyeX = player.getX();
        double eyeY = player.getEyeY();
        double eyeZ = player.getZ();
        double range = TriggerConfig.aimRange;
        double rangeSq = range * range;
        double halfFov = TriggerConfig.aimFov / 2.0;
        float yaw = player.getYaw();
        float pitch = player.getPitch();

        // Берём только сущностей рядом, а не весь мир.
        Box box = new Box(eyeX - range, eyeY - range, eyeZ - range,
                eyeX + range, eyeY + range, eyeZ + range);

        double bestAngle = halfFov;
        double bestDYaw = 0;
        double bestDPitch = 0;
        boolean found = false;

        for (LivingEntity entity : client.world.getEntitiesByClass(LivingEntity.class, box, VALID)) {
            double tx = entity.getX();
            double ty = TriggerConfig.aimHead ? entity.getEyeY() : entity.getY() + entity.getHeight() * 0.5;
            double tz = entity.getZ();

            double dx = tx - eyeX;
            double dy = ty - eyeY;
            double dz = tz - eyeZ;
            if (dx * dx + dy * dy + dz * dz > rangeSq) continue;

            double horizontal = Math.sqrt(dx * dx + dz * dz);
            double targetYaw = Math.toDegrees(Math.atan2(dz, dx)) - 90.0;
            double targetPitch = -Math.toDegrees(Math.atan2(dy, horizontal));

            double dYaw = MathHelper.wrapDegrees(targetYaw - yaw);
            double dPitch = targetPitch - pitch;
            double angle = Math.sqrt(dYaw * dYaw + dPitch * dPitch);
            if (angle >= bestAngle) continue;

            // Дорогая проверка видимости (raycast) — только для лучших кандидатов.
            if (!player.canSee(entity)) continue;

            bestAngle = angle;
            bestDYaw = dYaw;
            bestDPitch = dPitch;
            found = true;
        }

        if (!found) return;

        double speed = TriggerConfig.aimSpeed / 100.0;
        player.setYaw(yaw + (float) (bestDYaw * speed));
        player.setPitch(MathHelper.clamp(pitch + (float) (bestDPitch * speed), -90.0f, 90.0f));
    }
}
