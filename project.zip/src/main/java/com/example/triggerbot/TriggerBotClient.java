package com.example.triggerbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.EntityHitResult;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TriggerBotClient implements ClientModInitializer {
    public static final String MOD_ID = "triggerbot";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static KeyBinding menuKeyB;
    private static KeyBinding menuKeyM;
    private static KeyBinding toggleKey;
    private static KeyBinding aimToggleKey;

    /** Момент времени (мс), когда нужно ударить; -1 — таймер не запущен. */
    private long attackAt = -1;

    @Override
    public void onInitializeClient() {
        TriggerConfig.load();

        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of(MOD_ID, "main"));

        menuKeyB = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbot.menu_b", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_B, category));
        menuKeyM = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbot.menu_m", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_M, category));
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbot.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, category));
        aimToggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbot.toggle_aim", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, category));

        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    private void onTick(MinecraftClient client) {
        boolean openMenu = false;
        while (menuKeyB.wasPressed()) openMenu = true;
        while (menuKeyM.wasPressed()) openMenu = true;

        while (toggleKey.wasPressed()) {
            TriggerConfig.enabled = !TriggerConfig.enabled;
            attackAt = -1;
            notifyState(client, "triggerbot.title", TriggerConfig.enabled);
        }
        while (aimToggleKey.wasPressed()) {
            TriggerConfig.aimEnabled = !TriggerConfig.aimEnabled;
            notifyState(client, "triggerbot.tab_aim", TriggerConfig.aimEnabled);
        }

        if (openMenu && client.player != null && client.currentScreen == null) {
            client.setScreen(new TriggerScreen());
            return;
        }

        AimAssist.tick(client);
        runTrigger(client);
    }

    private static void notifyState(MinecraftClient client, String nameKey, boolean state) {
        if (client.player == null) return;
        client.player.sendMessage(
                Text.translatable(nameKey)
                        .append(Text.literal(": "))
                        .append(TriggerScreen.onOff(state)),
                true);
    }

    private void runTrigger(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (!TriggerConfig.enabled
                || player == null
                || client.world == null
                || client.interactionManager == null
                || client.currentScreen != null
                || player.isSpectator()
                || player.isUsingItem()) {
            attackAt = -1;
            return;
        }

        if (!(client.crosshairTarget instanceof EntityHitResult hit)) {
            attackAt = -1;
            return;
        }

        Entity target = hit.getEntity();
        if (!Targets.isValid(target)) {
            attackAt = -1;
            return;
        }

        if (TriggerConfig.weaponOnly) {
            ItemStack held = player.getMainHandStack();
            if (!(held.isIn(ItemTags.SWORDS) || held.isIn(ItemTags.AXES))) {
                attackAt = -1;
                return;
            }
        }

        // Ждём, пока перезарядится оружие.
        if (player.getAttackCooldownProgress(0.0f) < TriggerConfig.cooldownPercent / 100.0f) {
            return;
        }

        long now = System.currentTimeMillis();
        if (attackAt < 0) {
            attackAt = now + TriggerConfig.delayMs;
        }
        if (now < attackAt) {
            return;
        }

        client.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
        attackAt = -1;
    }
}
