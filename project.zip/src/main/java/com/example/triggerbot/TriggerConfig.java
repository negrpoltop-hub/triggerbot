package com.example.triggerbot;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class TriggerConfig {
    /** Не сохраняется: после запуска игры бот всегда выключен. */
    public static boolean enabled = false;

    public static boolean targetPlayers = true;
    public static boolean targetHostile = true;
    public static boolean targetPassive = false;
    public static boolean weaponOnly = false;
    /** Минимальная «сила удара» (кулдаун оружия) в процентах, 50..100. */
    public static int cooldownPercent = 100;
    /** Задержка перед ударом в миллисекундах, 0..300. */
    public static int delayMs = 0;

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("triggerbot.properties");
    }

    private TriggerConfig() {}

    public static void load() {
        Path file = file();
        if (!Files.exists(file)) return;
        Properties p = new Properties();
        try (Reader in = Files.newBufferedReader(file)) {
            p.load(in);
            targetPlayers = Boolean.parseBoolean(p.getProperty("targetPlayers", "true"));
            targetHostile = Boolean.parseBoolean(p.getProperty("targetHostile", "true"));
            targetPassive = Boolean.parseBoolean(p.getProperty("targetPassive", "false"));
            weaponOnly = Boolean.parseBoolean(p.getProperty("weaponOnly", "false"));
            cooldownPercent = clamp(parseInt(p.getProperty("cooldownPercent"), 100), 50, 100);
            delayMs = clamp(parseInt(p.getProperty("delayMs"), 0), 0, 300);
        } catch (IOException | RuntimeException e) {
            TriggerBotClient.LOGGER.warn("Could not read config", e);
        }
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("targetPlayers", Boolean.toString(targetPlayers));
        p.setProperty("targetHostile", Boolean.toString(targetHostile));
        p.setProperty("targetPassive", Boolean.toString(targetPassive));
        p.setProperty("weaponOnly", Boolean.toString(weaponOnly));
        p.setProperty("cooldownPercent", Integer.toString(cooldownPercent));
        p.setProperty("delayMs", Integer.toString(delayMs));
        try (Writer out = Files.newBufferedWriter(file())) {
            p.store(out, "TriggerBot");
        } catch (IOException e) {
            TriggerBotClient.LOGGER.warn("Could not save config", e);
        }
    }

    private static int parseInt(String s, int fallback) {
        try {
            return s == null ? fallback : Integer.parseInt(s.trim());
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    private static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }
}
