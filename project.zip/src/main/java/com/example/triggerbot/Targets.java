package com.example.triggerbot;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.entity.player.PlayerEntity;

/** Общий фильтр целей для TriggerBot и доводки. */
public final class Targets {
    private Targets() {}

    public static boolean isValid(Entity entity) {
        if (!(entity instanceof LivingEntity living)
                || !living.isAlive()
                || living.isSpectator()
                || !living.isAttackable()
                || entity instanceof ArmorStandEntity) {
            return false;
        }

        PlayerEntity self = MinecraftClient.getInstance().player;
        if (entity == self) return false;

        // Не бьём собственных прирученных питомцев.
        if (self != null && entity instanceof TameableEntity pet && pet.isTamed() && pet.isOwner(self)) {
            return false;
        }

        if (entity instanceof PlayerEntity) return TriggerConfig.targetPlayers;
        if (entity instanceof Monster) return TriggerConfig.targetHostile;
        return TriggerConfig.targetPassive;
    }
}
