package com.example.triggerbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.EntityHitResult;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TriggerBotClient implements ClientModInitializer {
    public static final String MOD_ID = "triggerbot";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static KeyBinding menuKeyB;
    private static KeyBinding menuKeyM;
    private static KeyBinding toggleKey;
    private static KeyBinding aimToggleKey;

    /** Момент времени (мс), когда нужно ударить; -1 — таймер не запущен. */
    private long attackAt = -1;

    /** Слот, который был выбран до авто-свапа на копьё (-1 — свапа не было). */
    private int swappedFrom = -1;
    /** Слот копья, на который мы переключились. */
    private int swappedTo = -1;

    /** Сколько максимум ждать удобного момента для крита, мс. */
    private static final long CRIT_TIMEOUT_MS = 1000;
    /** Когда начали ждать крит (-1 — не ждём). */
    private long critSince = -1;
    /** Мы сами нажали прыжок и должны отпустить его в следующий тик. */
    private boolean jumpPressedByUs = false;

    @Override
    public void onInitializeClient() {
        TriggerConfig.load();

        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of(MOD_ID, "main"));

        menuKeyB = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbot.menu_b", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_B, category));
        menuKeyM = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbot.menu_m", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_M, category));
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbot.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, category));
        aimToggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbot.toggle_aim", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, category));

        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    private void onTick(MinecraftClient client) {
        if (jumpPressedByUs) {
            client.options.jumpKey.setPressed(false);
            jumpPressedByUs = false;
        }

        boolean openMenu = false;
        while (menuKeyB.wasPressed()) openMenu = true;
        while (menuKeyM.wasPressed()) openMenu = true;

        while (toggleKey.wasPressed()) {
            TriggerConfig.enabled = !TriggerConfig.enabled;
            attackAt = -1;
            restoreSlot(client.player);
            notifyState(client, "triggerbot.title", TriggerConfig.enabled);
        }
        while (aimToggleKey.wasPressed()) {
            TriggerConfig.aimEnabled = !TriggerConfig.aimEnabled;
            notifyState(client, "triggerbot.tab_aim", TriggerConfig.aimEnabled);
        }

        if (openMenu && client.player != null && client.currentScreen == null) {
            client.setScreen(new TriggerScreen());
            return;
        }

        AimAssist.tick(client);
        runTrigger(client);
    }

    private static void notifyState(MinecraftClient client, String nameKey, boolean state) {
        if (client.player == null) return;
        client.player.sendMessage(
                Text.translatable(nameKey)
                        .append(Text.literal(": "))
                        .append(TriggerScreen.onOff(state)),
                true);
    }

    private static boolean isSpear(ItemStack stack) {
        return !stack.isEmpty()
                && Registries.ITEM.getId(stack.getItem()).getPath().endsWith("_spear");
    }

    /** Рывок (Lunge) тратит голод при ударе копьём. */
    private static boolean hasLunge(ItemStack stack) {
        for (var entry : stack.getEnchantments().getEnchantments()) {
            if (entry.getKey().isPresent()
                    && entry.getKey().get().getValue().getPath().equals("lunge")) {
                return true;
            }
        }
        return false;
    }

    /** Ищет в хотбаре копьё без Рывка; сначала проверяет слот в руке. -1 — не нашли. */
    private static int findSafeSpear(ClientPlayerEntity player) {
        int selected = player.getInventory().getSelectedSlot();
        ItemStack held = player.getInventory().getStack(selected);
        if (isSpear(held) && !hasLunge(held)) return selected;
        for (int i = 0; i < 9; i++) {
            ItemStack st = player.getInventory().getStack(i);
            if (isSpear(st) && !hasLunge(st)) return i;
        }
        return -1;
    }

    /** Может ли удар вообще быть критическим в текущем состоянии (вода, лестница, слепота и т.д. — нет). */
    private static boolean critPossible(ClientPlayerEntity player) {
        return !player.isTouchingWater()
                && !player.isClimbing()
                && !player.hasVehicle()
                && !player.hasStatusEffect(StatusEffects.BLINDNESS)
                && !player.getAbilities().flying;
    }

    /** Крит: в воздухе, уже падаем и не бежим (спринт отменяет крит). */
    private static boolean canCritNow(ClientPlayerEntity player) {
        return !player.isOnGround()
                && player.getVelocity().y < -0.05
                && !player.isSprinting();
    }

    private void restoreSlot(ClientPlayerEntity player) {
        if (swappedFrom >= 0 && player != null && TriggerConfig.spearSwapBack
                && player.getInventory().getSelectedSlot() == swappedTo) {
            player.getInventory().setSelectedSlot(swappedFrom);
        }
        swappedFrom = -1;
        swappedTo = -1;
    }

    private void idle(ClientPlayerEntity player) {
        attackAt = -1;
        critSince = -1;
        restoreSlot(player);
    }

    private void runTrigger(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (!TriggerConfig.enabled
                || player == null
                || client.world == null
                || client.interactionManager == null
                || client.currentScreen != null
                || player.isSpectator()
                || !player.isAlive()
                || player.isUsingItem()) {
            idle(player);
            return;
        }

        if (!(client.crosshairTarget instanceof EntityHitResult hit)) {
            idle(player);
            return;
        }

        Entity target = hit.getEntity();
        if (!Targets.isValid(target)) {
            idle(player);
            return;
        }

        // Авто-свап на копьё БЕЗ Рывка (Lunge), чтобы не терять голод.
        if (TriggerConfig.autoSpear) {
            int slot = findSafeSpear(player);
            int selected = player.getInventory().getSelectedSlot();
            if (slot >= 0) {
                if (slot != selected) {
                    if (swappedFrom < 0) swappedFrom = selected;
                    swappedTo = slot;
                    player.getInventory().setSelectedSlot(slot);
                    attackAt = -1;
                    return; // после смены предмета кулдаун сбрасывается — ждём
                }
            } else {
                ItemStack held = player.getMainHandStack();
                if (isSpear(held) && hasLunge(held)) {
                    attackAt = -1; // копьё с Рывком в руке — не бьём, голод целее
                    return;
                }
            }
        }

        if (TriggerConfig.weaponOnly) {
            ItemStack held = player.getMainHandStack();
            if (!(held.isIn(ItemTags.SWORDS) || held.isIn(ItemTags.AXES) || isSpear(held))) {
                attackAt = -1;
                return;
            }
        }

        // Ждём, пока перезарядится оружие.
        if (player.getAttackCooldownProgress(0.0f) < TriggerConfig.cooldownPercent / 100.0f) {
            return;
        }

        long now = System.currentTimeMillis();
        if (attackAt < 0) {
            attackAt = now + TriggerConfig.delayMs;
        }
        if (now < attackAt) {
            return;
        }

        // Авто-крит: ждём падения (и сами прыгаем, если разрешено), но не дольше таймаута.
        if (TriggerConfig.autoCrit && critPossible(player)) {
            if (critSince < 0) critSince = now;
            if (!canCritNow(player) && now - critSince < CRIT_TIMEOUT_MS) {
                if (TriggerConfig.autoJump && player.isOnGround() && !jumpPressedByUs) {
                    client.options.jumpKey.setPressed(true);
                    jumpPressedByUs = true;
                }
                return;
            }
        }

        client.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
        attackAt = -1;
        critSince = -1;
    }
}
